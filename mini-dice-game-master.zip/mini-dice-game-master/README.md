# mini-dice-game
A simple OOP PHP dice game.

A simple PHP dice game that I made as a school project. 
It was developed in HTML, OOP PHP and MySQLi.

<b>LICENSE</b><br />
This project is licensed under the [licenceType] License - see the [LICENSE.md](LICENSE) file for details
